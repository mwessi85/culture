<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php
if(isset($_GET['id'])){
	$query = "SELECT * FROM clans WHERE id = ".$_GET['id'];
	$result = mysql_query($query, $connection);
	$clan = mysql_fetch_array($result);
}
if(isset($clan)){
	$local_name = $clan['local_name'];
	$head = $clan['head'];
	$slogan = $clan['slogan'];
	$totem = $clan['totem'];
	$second_totem= $clan['second_totem'];
	$history = $clan['history'];
	$totem_image = $clan['totem_image'];
}else{
	$local_name = "";
	$head = "";
	$slogan = "";
	$totem = "";
	$second_totem = "";
	$history = "";
	$head_image = "";
	$totem_image = "";	
}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2><?php echo ucfirst($local_name);?></h2>
        <?php show_errors();?>
        <?php if(!empty($message)){echo "<p class=\"notice\">".$message."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a>
        <table class='results'>
        <tr><td>Totem</td><td><?php echo $totem; ?></td></tr>
        <tr><td colspan="2"><img src="<?php echo $totem_image;?>" alt="<?php echo $totem;?>" title="<?php echo $totem;?>" style="width:100px; height:100px;"/></td></tr>
        <tr><td>Head</td><td><?php echo $head; ?></td></tr>
        <tr><td>Slogan</td><td><?php echo $slogan; ?></td></tr>
        <tr><td>History</td><td><?php echo $history; ?></td></tr>
        </table>
        <?php 
		$query = "SELECT * FROM names WHERE clan =".$_GET['id'];
		$result = mysql_query($query, $connection);
		$rows = mysql_num_rows($result);
		?>
        <table>
        <tr>
        <td class='column_head'>Names (<?php echo $rows;?>)</td>
        <td class='column_head'>Gender</td>
        <td class='column_head'>Notes</td>
        </tr>
        <?php 
		
		while($name = mysql_fetch_assoc($result)){
			if(isset($name)){
				$query = "SELECT * FROM clans WHERE id = ".$name['clan'];
				$result_2 = mysql_query($query, $connection);
				$clan = mysql_fetch_array($result_2);
			}
			echo "<tr>
			<td>".$name['name']."</td>
			<td>".$name['gender']."</td>
			<td>".$name['notes']."</td>
			<td><a href='name_add_edit.php?id=".$name['id']."'>Edit</a></td>
			</tr>";
		}
		?>
        </table>
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>