<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php
if(isset($_GET['id'])){
	$query = "SELECT * FROM clans WHERE id = ".$_GET['id'];
	$result = mysql_query($query, $connection);
	$clan = mysql_fetch_array($result);
	$action = "edit";
	$title = "Edit";	
}else{
	$action = "add";
	$title = "Add";	
}
if(isset($clan)){
	$local_name = $clan['local_name'];
	$head = $clan['head'];
	$slogan = $clan['slogan'];
	$totem = $clan['totem'];
	$second_totem= $clan['second_totem'];
	$history = $clan['history'];
	$totem_image = $clan['totem_image'];
}else{
	$local_name = "";
	$head = "";
	$slogan = "";
	$totem = "";
	$second_totem = "";
	$history = "";
	$head_image = "";
	$totem_image = "";	
}




if(isset($_POST['submit'])){	
	$errors = array();
	if(isset($_POST['local_name'])){
		$local_name = trim($_POST['local_name']);	
	}
	if(isset($_POST['head'])){
		$head = trim($_POST['head']);	
	}
	if(isset($_POST['slogan'])){
		$slogan = trim($_POST['slogan']);	
	}
	if(isset($_POST['totem'])){
		$totem = trim($_POST['totem']);	
	}
	if(isset($_POST['second_totem'])){
		$second_totem = trim($_POST['second_totem']);	
	}
	if(isset($_POST['history'])){
		$history = trim($_POST['history']);	
	}	
	if(isset($_POST['totem_image'])){
		$totem_image = trim($_POST['totem_image']);	
		$old_file = trim($_POST['totem_image']);
	}

	$upload_errors = array(
			UPLOAD_ERR_OK => "No errors",
			UPLOAD_ERR_INI_SIZE => "Larger than upload_max_filesize in php",
			UPLOAD_ERR_FORM_SIZE => "Larger than form MAX_FILE_SIZE",
			UPLOAD_ERR_PARTIAL => "Partial Upload",
			UPLOAD_ERR_NO_FILE => "No file",
			UPLOAD_ERR_NO_TMP_DIR => "No temporaty directory",
			UPLOAD_ERR_CANT_WRITE => "Can't Write to disk",
			UPLOAD_ERR_EXTENSION => "File upload stopped by extension"
		);
	if(isset($_FILES['file_upload'])){
		
		if($_FILES['file_upload']['error'] == 0){
			$tmp_file = $_FILES['file_upload']['tmp_name'];
			$target_file = str_replace(" ", '_', $local_name);
			$target_file = strtolower($target_file);
			$upload_dir = "uploads";
			$file = $upload_dir."/".$target_file.".jpg";
			chmod($file, 0777);
			}elseif($_POST['totem_image']!=""){
				$file = $_POST['totem_image'];	
			}	
			else{
				$errors['not file was uploaded'] = "";	
			}
	}
	if($_POST['submit'] == "Add"){
		$query = "SELECT * FROM clans WHERE local_name ='".$local_name."'";
		echo $query;
		$result = mysql_query($query, $connection);
		$num_rows = mysql_num_rows($result);
		if($num_rows >= 1){
			$errors['the clan was already entered'] = "";
		}
		if(isset($tmp_file) && isset($file) ){
			if(move_uploaded_file($tmp_file, $file)){					
				$query = "INSERT INTO clans(local_name, head, slogan, totem, second_totem, history, totem_image) 
				VALUES('".$local_name."', '".$head."', '".$slogan."', '".$totem."', '".$second_totem."', 
				'".$history."', '".$file."')";
			}
		}else{
			$query = "INSERT INTO clans(local_name, head, slogan, totem, second_totem, history) 
			VALUES('".$local_name."', '".$head."', '".$slogan."', '".$totem."', '".$second_totem."', '".$history."')";
		}
		$result = mysql_query($query, $connection);
		$clan_id = mysql_insert_id($connection);	
		if(isset($result)){
			$message = "The clan was sucessfully added";
			header("location: clans.php?id=".$clan_id ."&success_message=".$message);
		}	
	}
	elseif($_POST['submit'] == "Edit"){		
		if(isset($file) & isset($tmp_file)){
			$target_file = str_replace(" ", '_', $local_name);
			if(isset($tmp_file) && isset($_POST['totem_image'])){
				if (file_exists($_POST['totem_image'])) {
					unlink($_POST['totem_image']);	
				}
			}
			if(move_uploaded_file($tmp_file, $file)){					
				$query = "UPDATE clans SET totem_image = '".$file."' WHERE id = ".$_GET['id'];
				$result = mysql_query($query, $connection);
			}
		}
			$query = "UPDATE clans SET local_name = '".$local_name."', head = '".$head."', slogan = '".$slogan."', totem = '".$totem."', second_totem = '".$second_totem."', history = '".$history."' WHERE id = ".$_GET['id'];
			echo $query;
			//exit;
			$result = mysql_query($query, $connection);
			if(isset($result)){
				$message = "The clan was sucessfully updated";
				header("location: clans.php?id=".$_GET['id']."&success_message=".$message);
			}
		}
	}



?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2><?php echo $title;?></h2>
        <?php show_errors();?>
        <?php if(!empty($message)){echo "<p class=\"notice\">".$message."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a>
        <?php 
		//echo $sql;
		?>
        <table class='results'>
        <form autocomplete="off" action="clan_add_edit.php<?php if(isset($_GET['id']))echo "?id=".$_GET['id'];?>" method="post" enctype="multipart/form-data">
            <tr>
                <td class="cell_value bold">Clan:</td><td class="cell_value"><input type="search" name="local_name" id="local_name" autofocus placeholder="clan local name" value="<?php echo $local_name; ?>" required/>
                </td>
            </tr>
            <tr>
                <td class="cell_value bold">Totem:</td><td class="cell_value"><input type="search" name="totem" id="totem" autofocus placeholder="clan totem" value="<?php echo $totem; ?>" required/>
                </td>
            </tr>	
            <tr>
                <td class="cell_value bold">Head:</td><td class="cell_value"><input type="search" name="head" id="head" autofocus placeholder="name of the clan head" value="<?php echo $head; ?>" required/>
                </td>
            </tr>
            <tr>
                <td class="cell_value bold">Slogan:</td><td class="cell_value"><input type="search" name="slogan" id="slogan" autofocus placeholder="clan slogan" value="<?php echo $slogan; ?>" required/>
                </td>
            </tr>
            
            <tr>
                <td class="cell_value bold">Brief History:</td><td class="cell_value"><textarea name="history" rows="10"placeholder="brief history on the clan"><?php echo $history;?></textarea>
                </td>
            </tr>
            <tr>
            <td class="cell_value bold">Totem picture</td><td class="cell_value"><input type="file" name="file_upload"><input type="hidden" name="MAX_FILE_SIZE" value="2097152" /></td></tr>
            <tr>
            <td class="cell_value"></td><td class="cell_value"><input type="submit" name="submit" id="submit" value="<?php echo ucfirst($action);?>" /></td>
            </tr>
            <input type="hidden" name="totem_image" id="totem_image" value="<?php echo $totem_image; ?>" />
        </form>
        </tr>
        </table>
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>