-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2015 at 09:03 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `culture`
--
CREATE DATABASE IF NOT EXISTS `culture` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `culture`;

-- --------------------------------------------------------

--
-- Table structure for table `clans`
--

CREATE TABLE IF NOT EXISTS `clans` (
`id` int(11) NOT NULL,
  `local_name` varchar(30) NOT NULL,
  `english_name` varchar(30) DEFAULT NULL,
  `head` varchar(30) DEFAULT NULL,
  `slogan` varchar(100) DEFAULT NULL,
  `totem` varchar(30) DEFAULT NULL,
  `second_totem` varchar(30) DEFAULT NULL,
  `history` text,
  `totem_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `clans`
--

INSERT INTO `clans` (`id`, `local_name`, `english_name`, `head`, `slogan`, `totem`, `second_totem`, `history`, `totem_image`) VALUES
(1, 'Mamba Kakoboza', NULL, 'Gabungaaa', 'blah blah', 'Mamba', '', 'Emmamba Kakoboza is one of the 56 clans of the Buganda Kingdom. The Emmamba Kakoboza chief is Gabunga, whose headquarters are located in .......... in ......... County in Uganda. The Emmamba Kakooboza clan has the mamba, a Luganda word for Lung Fish, as its totem.', 'uploads/mamba.jpg'),
(2, 'Butiko', NULL, 'Kakeeto', 'Blah blah blah', 'Butiko', '', 'hgsjsfk ihdkfgidjbgfi ihdfid igijdigfid', 'uploads/butiko.jpg'),
(3, 'Mpindi', NULL, 'Mazige', 'Samba Egoto', 'Mpindi', '', 'Mpindi is one of the 56 clans of the Buganda Kingdom, one of the largest nations of Uganda. The Mpindi chief is Mazige, whose headquarters are located in Muyenje in Busiro County in Uganda. The Mpindi clan has the mpindi, a Luganda word for cowpea (Vigna unguiculalta), as its totem.', 'uploads/mpindi.jpg'),
(4, 'Ngabi', NULL, 'Nsamba', 'Kalikutanda', 'Gylengesa', '', 'blah blah', NULL),
(5, 'Mpologoma', NULL, 'Namuguzi', 'yaaahhhhhh', 'Mpologoma', '', '', 'uploads/mpologoma.jpg'),
(6, 'Abalangira', NULL, 'Baleke', 'yaaahhh', 'totem-Abalangira N`abambejja', '', 'This is the ruling clan of Buganda which follows the maternal lineage. This maternal system helps the Kingship of Buganda to revolve from clan to clan as different women from various clans marry into the royal family.', NULL),
(7, 'Ekkobe kaama', NULL, 'Namwama', 'Kasonzi mulwadde', 'kaama (type of wild creepingbe', '', 'There is a legend that a man once went to visit his in-laws and saw very good air potatoes. He had food scarcity at his home and never wanted his in-laws to know, so he decided to help himself.', NULL),
(8, 'Ensenene', NULL, 'Mugalula', 'Nakimera muka Ssuuna bwâ€™asa bwanegula.', 'Nabangogoma', '', 'Buyongaâ€™s daughter Wannyana was exceptionally beautiful and this earned her a privilege to mingle with royals of different kingdoms. She was a descendant of the Batoro of Mugamba hill, Busongola in Toro. Her father Buyonga was son of Kiroboozi who is said to be the grandfather of the Nsenene Clan.', NULL),
(9, 'Ente | etalina mukira', NULL, 'Katongole', 'Ekyuma nkiridde nâ€™omukimba ngulidde.', 'Nnnggaali', '', 'Although it is a rule that you donâ€™t eat your totem, the nte clansmen do eat beef yet a cow is their totem. There are seven specific types of cows that are totemic and the rest are not', NULL),
(10, 'Ngeye', NULL, 'Kasujja Nkalyesiiwa', 'Tatuula asuulumba busuulumbi', 'Kkunguvu', '', 'When Kintu overthrew Bemba, he could not be inaugurated king without a Muganda wife as it was required by the law of the land.', NULL),
(11, 'Akasimba', NULL, 'Kabazzi', 'Kiiso bwe kikulaba obulungi naawe okiraba.Kiiso bwe kikulaba obulungi naawe okiraba.', 'Engo', '', 'A man once sent her daughter in the field to herd his goats. While the goats grazed in the savannah, a leopard pounced on one and killed it.', NULL),
(12, 'Embogo', NULL, 'Kayiira Gajuule', 'Kyaana kya mbogo ssenge Katutu kaagwa', 'Ndeerwe - Type of Mashroom', '', 'It is believed that the Mbogo clansmen hailed from Bunyoro in a place called Mazigita near Kibulala. They came carrying Kimera to ascend the throne of his lost grandfather Ccwa Nabakka, son of Kalemeera.', NULL),
(13, 'Enjovu', NULL, 'Mukalo', 'Esimbye amasanga................Nakate ajja, Nakate ajja, ajja ayuga. Batte mmugamba tunguraka emu, ', 'Nvubu', '', 'The Njovu clansmen claim their descent from Sessanga who came with Kintu in Buganda and settled in Ntonnyeze in Busujju. He was Kintu`s herdsman and also took charge of his spears and arrows. It is in Ntonnyeze that he had his son Mukalo who became the first wealthy man in the entire clan and acquired many estates.', NULL),
(14, 'Enkerebwe', NULL, 'Kidimbo', 'Enkerebwe, Enkerebwe.......Enkulu, esima nga eggalira nga eggulira........', 'Kikirikisi', '', 'This group of people came from Bunyoro. They came with Prince Kimera on his way to ascend his grandfather`s (Kabaka Ccwa Nabakka) throne in Buganda.', NULL),
(15, 'Ensenene', NULL, 'Mugalula', 'Nakimera muka Ssuuna bwâ€™asa bwanegula.', 'Nabangogoma', '', 'Buyongaâ€™s daughter Wannyana was exceptionally beautiful and this earned her a privilege to mingle with royals of different kingdoms. She was a descendant of the Batoro of Mugamba hill, Busongola in Toro. Her father Buyonga was son of Kiroboozi who is said to be the grandfather of the Nsenene Clan.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `names`
--

CREATE TABLE IF NOT EXISTS `names` (
`id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `clan` int(11) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `notes` text
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `names`
--

INSERT INTO `names` (`id`, `name`, `clan`, `gender`, `notes`) VALUES
(1, 'Mutebi', 1, 'male', ''),
(2, 'Mazige', 3, 'male', 'Mazige... blah blah blah blah'),
(3, 'Mubiru', 1, 'male', 'Mubiru jsfksjdsb ksbdksbd ibskfdjsbhjsfd'),
(4, 'Matovu', 4, 'male', 'blah blah'),
(5, 'nakalema', 5, 'female', 'asws'),
(6, 'Batenga,', 6, 'male', ''),
(7, 'Batanda,', 6, 'male', ''),
(8, 'Kagere', 6, 'male', ','),
(9, 'Mazzi', 6, 'female', ''),
(10, 'Nakasagga', 6, 'female', ''),
(11, 'Nassolo', 6, 'female', ''),
(12, 'Nabadda', 6, 'female', ''),
(13, 'Nakabiri', 6, 'female', ''),
(14, 'Nakamaanya', 6, 'male', ''),
(15, 'Luwedde', 6, 'male', ''),
(16, 'Nakamaanya', 6, 'female', ''),
(17, 'Nakampi,', 6, 'female', ''),
(18, 'Ssekibuule,', 5, 'male', ''),
(19, 'Ssebuwufu', 5, 'male', ''),
(20, 'Sserwadda', 5, 'male', ''),
(21, 'Ntale', 5, 'male', ''),
(22, 'Nakitowoolo,', 5, 'female', ''),
(23, 'Nakibuule', 5, 'female', ''),
(24, 'Nabuwufu,', 5, 'female', ''),
(25, 'Nantale,', 5, 'female', ''),
(26, 'Nalwadda,', 5, 'female', ''),
(27, 'Kayiwa,', 7, 'male', ''),
(28, 'Busuulwa,', 7, 'male', ''),
(29, 'Kakinda,', 7, 'male', ''),
(30, 'Nsereko', 7, 'male', ''),
(31, 'Lwabiriza,', 7, 'male', ''),
(32, 'Namukangula,', 7, 'male', ''),
(33, 'Nassimbwa,', 7, 'female', ''),
(34, 'Nantumbwe,', 7, 'female', ''),
(35, 'Nababi,', 7, 'female', ''),
(36, 'Nakamatte,', 7, 'female', ''),
(37, 'Nakayiwa,', 7, 'female', ''),
(38, 'Namale,', 7, 'female', ''),
(39, ', Ssewannyana', 8, 'male', ''),
(40, 'Kajubi', 8, 'male', ''),
(41, 'Ssendawula,', 8, 'male', ''),
(42, 'Kalanzi,', 8, 'male', ''),
(43, 'Nakajubi', 8, 'female', ''),
(44, 'Nandawula,', 8, 'female', ''),
(45, 'Nakalanzi,', 8, 'female', ''),
(46, 'Nnamukwaya', 12, 'female', ''),
(47, 'Namagembe,', 12, 'female', ''),
(48, 'Nantamu,', 12, 'female', ''),
(49, 'Nannyanzi', 12, 'female', ''),
(50, 'Kyakonye', 12, 'female', ''),
(51, 'Majwega,', 12, 'male', ''),
(52, 'Kayanja,', 12, 'male', ''),
(53, 'Lutaakome,', 12, 'male', ''),
(54, 'Walakira', 12, 'male', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clans`
--
ALTER TABLE `clans`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `names`
--
ALTER TABLE `names`
 ADD PRIMARY KEY (`id`), ADD KEY `clan` (`clan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clans`
--
ALTER TABLE `clans`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `names`
--
ALTER TABLE `names`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=55;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
