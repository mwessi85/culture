<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2>Clans</h2>
        <?php show_errors();?>
        <?php if(isset($_GET['message'])){echo "<p class=\"notice\">".$_GET['message']."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a> | <a href="import.php">Export to json</a>
        
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>