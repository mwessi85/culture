<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php
$query = "SELECT * FROM clans ORDER BY local_name";
//echo $query;
//exit;
$result = mysql_query($query, $connection);
if(isset($result)){
	$content = "[\r\n";
	while($clan = mysql_fetch_array($result)){
		$content = $content."{'name':'".$clan['local_name']."',\r\n";
		$content = $content."'shortname':'".str_replace(" ", "_", strtolower($clan['local_name']))."',\r\n";
		$content = $content."'reknown':'".$clan['slogan']."',\r\n";
		//$content = $content."'bio':'".$clan['history']."'\r\n}, ";
		$sql = "SELECT * FROM names WHERE clan = ".$clan['id']." ORDER BY gender, name";
		$result_2 = mysql_query($sql, $connection);
		$content = $content."'bio':'".$clan['history']."Clan names include ";
		while($name = mysql_fetch_array($result_2)){
			$content = $content."".ucfirst($name['name'])." ".ucfirst($name['gender']).", ";		
		}
		$content = $content."'\r\n}, ";
	}
	$content .= "]";
}


//$content = '123\r\n456\r\n789';
$content = str_replace("' '", "'", $content);

$content = str_replace("' '}", "'}", $content);

$content = str_replace("'", '"', $content);
$content = str_replace(", ]", ']', $content);
//echo "<p>".$content."</p>";
//exit;

$message = write_to_json($content);

header("location: home.php?success_message=".$message);
?>