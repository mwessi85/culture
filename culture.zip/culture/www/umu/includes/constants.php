<?php
// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "atlas");
define("DB_PASS", "atlas618");
define("DB_NAME", "culture");
?>