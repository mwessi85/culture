<?php require_once("connection.php");?>
<?php 
//Query confirmation

function query_confirmation($result){
	if(!isset($result)){
		die("Database query failed: ".mysql_error());	
	}
}
function success_message(){
	if(isset($_GET['success_message'])){
		$message = $_GET['success_message'];
		return $message;
	}
	return false;
}
function error_message(){
	if(isset($_GET['error_message'])){
		$message = $_GET['error_message'];
		return $message;
	}
	return false;
}
function even_strip($i){
	 if($i%2 == 0){
		 $class = "class='even'";
	}else {
		$class = "class='cell_value'" ;
	}	
	return $class;
}
function zero_one($i){
	if($i == 0){
		return 1;
	}else{
		return 0;	
	}
}
function mysql_prep($value){
	$magic_quotes_active = get_magic_quotes_gpc();
	$new_enough_php = function_exists("mysql_real_escape_string"); // i.e. PHP >= v4.3.0
	if($new_enough_php){ // i.e. PHP v4.3.0 or higher
		//undo any magic quote effects so mysql_real_escape_string can do the work
		if($magic_quotes_active){
			$value = stripslashes($value);
		}
		$value = mysql_real_escape_string($value);
	} else{ // Before PHP >= v4.3.0 and magic quotes aren't on, add them manually
		if(!$magic_quotes_active){
			$value = addslashes($value);
		}
		//if magic quotes are active, then slashes already exist
	}
	return $value;
}
//Show errors
function show_errors(){
	global $errors;
	if(isset($errors)) {
		foreach ($errors as $key => $value) {
			echo "<div class='error'>".$key;
			echo $value."</div>";
		}
	}
}
function show_errors_warning(){
	global $errors;
	if(isset($errors)) {
		foreach ($errors as $key => $value) {
			echo "
			<div class='alert alert-warning'>
				<a class='close' data-dismiss='alert'>×</a>
				<h4 class='alert-heading'>Warning</h4>
				<div>
				<div>".$key." ".$value."</div>
				</div>
			</div>";
		}
	}
}

function show_alert_success($message){
			echo "
			<div class='alert alert-success'>
				<a class='close' data-dismiss='alert'>×</a>
				<h4 class='alert-heading'>Success!</h4>
				<div>
				<div>".$message."</div>
				</div>
			</div>";
}
function show_alert_fail($message){
			echo "
			<div class='alert alert-error'>
				<a class='close' data-dismiss='alert'>×</a>
				<h4 class='alert-heading'>Success!</h4>
				<div>
				<div>".$message."</div>
				</div>
			</div>";
}



//Redirection to a locaion
function redirect_to($location = NULL){
	if($location != NULL){
		header("location: ".$location);
		exit;
	}
}
function redirect_success($location = NULL, $message = NULL){
	if($location != NULL && $message != NULL){
		header("location: ".$location."?success_message=".$message);
		exit;
	}
}
function redirect_success_subject($location = NULL, $message = NULL, $subj_id){
	if($location != NULL && $message != NULL){
		header("location: ".$location."?success_message=".$message."&subj=".$subj_id);
		exit;
	}
}
function redirect_success_page($location = NULL, $message = NULL, $page_id){
	if($location != NULL && $message != NULL){
		header("location: ".$location."?success_message=".$message."&page=".$page_id);
		exit;
	}
}

//User Functions
function select_users(){
	global $connection;
	$query = "SELECT * FROM users ORDER BY last_name, first_name ASC ";
	$result = mysql_query($query, $connection);
	return $result;
}
function select_user($user_id){
	global $connection;
	$query = "SELECT * FROM users WHERE id = ".$user_id;
	$result = mysql_query($query, $connection);
	return $result;
}
 
function select_categories(){
	global $connection;
	$query = "SELECT * FROM category ORDER BY name";
	$result = mysql_query($query, $connection);
	return $result;
}

function select_category($category_id){
	global $connection;
	$query = "SELECT * FROM category WHERE id = ".$category_id;
	$result = mysql_query($query, $connection);
	return $result;
}

function select_units(){
	global $connection;
	$query = "SELECT * FROM units";
	$result = mysql_query($query, $connection);
	return $result;
}

function select_unit($unit_id){
	global $connection;
	$query = "SELECT * FROM units WHERE id = ".$unit_id;
	$result = mysql_query($query, $connection);
	return $result;
}

function select_items(){
	global $connection;
	$query = "SELECT * FROM item ORDER BY name, trade_name ASC ";
	$result = mysql_query($query, $connection);
	return $result;
}

function select_item($item_id){
	global $connection;
	$query = "SELECT * FROM item WHERE id = ".$item_id;
	$result = mysql_query($query, $connection);
	return $result;
}

function select_customers(){
	global $connection;
	$query = "SELECT * FROM customer ORDER BY last_name, first_name ASC";
	$result = mysql_query($query, $connection);
	return $result;
}
function select_customer($customer_id){
	global $connection;
	$query = "SELECT * FROM customer WHERE id = ".$customer_id;
	$result = mysql_query($query, $connection);
	return $result;
}

function level($level){
	if($level == "admin"){
		return "Administrator";
	}
	if($level == "staff"){
		return "Staff";
	}
	if($level == "user"){
		return "User";
	}
}
function status($status){
	if($status == 1){
		return "Active";
	}
	else{
		return "Inactive";	
	}	
}

function check_stock(){
	global $connection;
	echo " <h2 class='notification'>Notice</h1>
	<table>
        <tr>
        <td class='column_head'>Item</td>
        <td class='column_head'>Message</td>
        </tr>";
	$sql = "SELECT * FROM item WHERE cummulative_amount > 0 ORDER BY name, trade_name ASC";
	$result_item = mysql_query($sql, $connection);
	while($item = mysql_fetch_assoc($result_item)){
		$item_id = $item['id'];
		$item_category = $item['category'];
		$item_name = $item['name'];
		$trade_name = $item['trade_name'];
		$weight = $item['weight'];
		$unit = $item['unit'];
		$unit_result = select_unit($unit);
		$units = mysql_fetch_assoc($unit_result);
		$unit_name = $units['value'];
		$name = $item_name."/".$trade_name."".$weight." ".$unit_name;
		$comment = $item['comment'];
		$result = select_category($item_category);
		$category = mysql_fetch_assoc($result);
		$category_name = $category['name'];
		$current_amount = $item['current_amount'];
		$initial_amount = $item['initial_amount'];
		$threshold_amount = $item['initial_amount']*0.3;
		$cummulative_amount = $item['cummulative_amount'];
		$initial_amount = $item['initial_amount']*0.3;
		$expiry_date = $item['expiry_date'];
		
		if($current_amount == 0){
			echo "<tr><td><a href=\"item.php?id=".$item_id."\">".$name."</a></td>";
			echo "<td class='out_of_stock'>Out of Stock - 0 units left</td></tr>";
			$query_out = "UPDATE item SET comment = 'out of stock' WHERE id = ".$item_id;
			$result_out = mysql_query($query_out, $connection);
		}
		elseif ($current_amount <= $threshold_amount){
			$side_stock_out_message = $name." is running out of stock at: ".$current_amount." out of ".$initial_amount." units";
			echo "<tr><td><a href=\"item.php?id=".$item_id."\">".$name."</a></td>";
			echo "<td class='almost_out_of_stock'>Less that ".$threshold_amount." Units left</td></tr>";
			$query_below = "UPDATE item SET comment = 'below threshold' WHERE id = ".$item_id;
			$result_below = mysql_query($query_below, $connection);
		}
		else{
			$today = date("Y-m-d");
			$todaysDate = strtotime($today);
			$almost_expiryDate = strtotime($today);
			$expiryDate = strtotime($expiry_date);
			$almost_expiryDate = strtotime(date("Y-m-d", strtotime($expiry_date)) . " -1 month");
			if ($expiryDate<=$todaysDate){
				$side_expiry_message = $name." expired on ".$expiry_date;
				echo "<tr><tr><td><a href=\"item.php?id=".$item_id."\">".$name."</a></td>";
				echo "<td class='expired'>Expired on ".$expiry_date."</td></tr>";
				$query_exp = "UPDATE item SET comment = 'expired' WHERE id = ".$item_id;
				$result_exp = mysql_query($query_exp, $connection);
			}else if($almost_expiryDate<=$todaysDate){
				$side_expiry_message = $name." expires on ".$expiry_date;
				echo "<tr><tr><td><a href=\"item.php?id=".$item_id."\">".$name."</a></td>";
				echo "<td class='almost_expired'>Expires on ".$expiry_date."</td></tr>";
			}
		}
	}
	echo "</table>";
}

function show_receipt(){
	global $connection;
	$query_sale_no = "SELECT * FROM item_sold ORDER BY sale_no DESC LIMIT 1";
	$result_sale_no = mysql_query($query_sale_no, $connection);
	$sale_no_array = mysql_fetch_array($result_sale_no);
	$sale_no = $sale_no_array['sale_no'];
	$query = "SELECT * FROM item_sold WHERE sale_no = ".$sale_no;
	$result = mysql_query($query, $connection);
	$sold_customer = mysql_fetch_array(mysql_query($query, $connection));
	echo "<h1>Previous Sale</h1>";
	echo "<h3>Customer: ".$sold_customer['customer_name']."</h3>";
	echo "<h3>Date: ".$sold_customer['date_sold']."</h3>";
	echo " <table class='results'>
        <tr>
        <td class='column_head'></td>
		<td class='column_head'>Inventory Item</td>
        <td class='column_head'>Amount</td>
        <td class='column_head'>Unit Cost</td>
        <td class='column_head'>Total</td>
        </tr>";
	$i = 0;
	$total_sold = 0;
	while($sold = mysql_fetch_array($result)){
		$item_name = $sold['item_name'];
		$sold_amount = $sold['sold_amount'];
		$selling_price = $sold['selling_price'];
		$sold = $sold['selling_price'] * $sold_amount;
		$staff = $sold['staff'];
		$total_sold = $total_sold + $sold;
		echo "
		<tr>
			<td class='cell_value'>".++$i."</td>
			<td class='cell_value'>".$item_name."</td>
			<td class='cell_value'>".$sold_amount."</td>
			<td class='cell_value'>".$selling_price."</td>
			<td class='cell_value'>".$sold."</td>";
			echo "</tr>";
		}
		
	echo " <tr>
            <td></td>
            <td class='column_head'></td>
            <td class='column_head'></td>
            <td class='column_head'></td>
            <td class='column_head'>".$total_sold."</td>
            </tr>
        </table>";
}


function get_logged_user_in(){
	if(isset($_SESSION['user_id'])){
		global $connection;
		$user_id = $_SESSION['user_id'];
		$query = "SELECT * FROM users WHERE id=".$user_id;
		$result = mysql_query($query, $connection);
		if(mysql_num_rows($result) == 1){
			$logged_user = mysql_fetch_array($result);
			/*$logged_user_name = ucfirst($logged_user['first_name'])." ".ucfirst(substr($logged_user['last_name'], 0, 1));*/
			$logged_user_name = ucfirst($logged_user['first_name']);
			return $logged_user_name;
		}
	}	
}
function get_logged_user(){
	if(isset($_SESSION['user_id'])){
		global $connection;
		$user_id = $_SESSION['user_id'];
		$query = "SELECT * FROM users WHERE id=".$user_id;
		$result = mysql_query($query, $connection);
		if(mysql_num_rows($result) == 1){
			$logged_user = mysql_fetch_array($result);
			$logged_user_name = ucfirst($logged_user['last_name'])." ".ucfirst($logged_user['first_name']);
			return $logged_user_name;
		}
	}	
}
function get_users_name($user_id){
	global $connection;
	$query = "SELECT * FROM users WHERE id=".$user_id;
	$result = mysql_query($query, $connection);
	if(mysql_num_rows($result) == 1){
		$users = mysql_fetch_array($result);
		$users_name = ucfirst($users['last_name'])." ".ucfirst($users['first_name']);
		return $users_name;
	}	
}

function drug_expired($expiry){
		// Find todays date.
		$today = date("Y-m-d");
		$todaysDate = strtotime($today);
		$expiryDate = strtotime($expiry);
		if ($expiryDate<=$todaysDate){
			return 'Expired';
		}else{
			return 'Not Expired';
		}
}
function isValidEmail($email) {
	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		return true;
	}else{
		return false;	
	}
}
function isValidPhone($phone) {
	if (strlen($phone)==10) {
		return true;
	}else{
		return false;	
	}
}
function isValidIp($ip) {
	if (filter_var($ip, FILTER_VALIDATE_IP)) {
		return true;
	}else{
		return false;	
	}
}
function isValidInt($int) {
	if (filter_var($int, FILTER_VALIDATE_INT)) {
		return true;
	}else{
		return false;	
	}
}

function diff_months($date1, $date2){
	
	$ts1 = strtotime($date1);
	$ts2 = strtotime($date2);
	
	$year1 = date('Y', $ts1);
	$year2 = date('Y', $ts2);
	
	$month1 = date('m', $ts1);
	$month2 = date('m', $ts2);
	
	$diff = (($year2 - $year1) * 12) + ($month2 - $month1);
	return $diff;
}
function return_month($month){
	if($month == 1){
		return "jan";
	}
	if($month == 2){
		return "feb";
	}
	if($month == 3){
		return "march";
	}
	if($month == 4){
		return "april";
	}
	if($month == 5){
		return "may";
	}
	if($month == 6){
		return "june";
	}
	if($month == 7){
		return "july";
	}
	if($month == 8){
		return "aug";
	}
	if($month == 9){
		return "sept";
	}
	if($month == 10){
		return "oct";
	}
	if($month == 11){
		return "nov";
	}
	if($month == 12){
		return "dec";
	}
}
function admin_nav(){
$admin_nav = "
<ul>
<li><a href='main.php'>Home</a></li>
<li><a href='users.php'>Identify Me</a></li>
<li><a href='items.php'>Inventory</a></li>
<li><a href='books.php'>Stock taking</a></li>
</ul>
";
return $admin_nav;
}
function clerk_nav(){
$clerk_nav = "
<h1>Users</h1>
<ul>
<li><a href='main.php'>Home</a></li>
</ul>
<h1>Sales</h1>
<ul>

</ul>
";
return $clerk_nav;
}
function xlsBOF() {
echo pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);
}
function xlsEOF() {
	echo pack("ss", 0x0A, 0x00);
}
function xlsWriteNumber($Row, $Col, $Value) {
	echo pack("sssss", 0x203, 14, $Row, $Col, 0x0);
	echo pack("d", $Value);
}
function xlsWriteLabel($Row, $Col, $Value) {
	$L = strlen($Value);
	echo pack("ssssss", 0x204, 8 + $L, $Row, $Col, 0x0, $L);
	echo $Value;
}

function excel_items(){
global $connection; 
// prepare headers information
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment; filename=\"export_".date("Y-m-d").".xls\"");
header("Content-Transfer-Encoding: binary");
header("Pragma: no-cache");
header("Expires: 0");
// start exporting
xlsBOF();
// first row 
xlsWriteLabel(0, 0,"ID");
xlsWriteLabel(0, 1,"Serial");;
xlsWriteLabel(0, 2,"Type");
xlsWriteLabel(0, 3,"Brand");
xlsWriteLabel(0, 4,"Location");
xlsWriteLabel(0, 5,"Physical state");
xlsWriteLabel(0, 6,"working state");
xlsWriteLabel(0, 7,"Status");
// second row 
$query = "SELECT i.id id, it.name type ,i.serial serial, b.name brand, l.location location, i.status status
			FROM item i JOIN item_type it JOIN brand b JOIN location l WHERE i.item_type = it.id AND i.brand = b.id AND i.location = l.id AND status = 'active'";
$result=mysql_query($query, $connection);
$xlsRow = 1;
	while($row=mysql_fetch_assoc($result))
	{
		$sql = "SELECT * FROM `condition` WHERE item_id = ".$row['id'];
		$result_condition = mysql_query($sql, $connection);
		$condition = mysql_fetch_array($result_condition);
		xlsWriteNumber($xlsRow, 0, $row['id']);
		xlsWriteLabel($xlsRow, 1, $row['serial']);
		xlsWriteLabel($xlsRow, 2, $row['type']);
		xlsWriteLabel($xlsRow, 3, $row['brand']);
		xlsWriteLabel($xlsRow, 4, $row['location']);
		xlsWriteLabel($xlsRow, 5, $condition['physical']);
		xlsWriteLabel($xlsRow, 6, $condition['working']);
		xlsWriteLabel($xlsRow, 7, $row['status']);
		$xlsRow++;
	}
xlsEOF();
}
function excel_books(){
global $connection; 
// prepare headers information
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment; filename=\"export_".date("Y-m-d").".xls\"");
header("Content-Transfer-Encoding: binary");
header("Pragma: no-cache");
header("Expires: 0");
// start exporting
xlsBOF();
// first row 
xlsWriteLabel(0, 0,"Barcode");
xlsWriteLabel(0, 1,"Call Number");
xlsWriteLabel(0, 2,"Item Type");
xlsWriteLabel(0, 3,"Title");
xlsWriteLabel(0, 4,"Branch");
xlsWriteLabel(0, 5,"Date Created");
xlsWriteLabel(0, 6,"Last borrowed");
xlsWriteLabel(0, 7,"Status");
xlsWriteLabel(0, 8,"Comment");
xlsWriteLabel(0, 9,"Staff");
// second row 
$query = "SELECT * FROM books";
$result=mysql_query($query, $connection);
$xlsRow = 1;
	while($row=mysql_fetch_assoc($result))
	{
		if($row['item_type_1'] == ""){
					$item_type = $row['item_type_2'];
				} else{ 
					$item_type = $row['item_type_1'];
				}
				
				
				if($row['last_borrowed']== "0000-00-00"){
					$last_borrowed = " - ";	
				}else{
					$f_last_borrowed = strtotime($row['last_borrowed']);
					$last_borrowed = date("j-M-Y", $f_last_borrowed);	
				}
				if($row['date_created']== "0000-00-00"){
					$date_created = " - ";	
				}else{
					$f_date_created = strtotime($row['date_created']);
					$date_created = date("j-M-Y", $f_date_created);	
				}
				if($row['staff'] >= 1){
					$date_created = " - ";	
				}else{
					$f_date_created = strtotime($row['date_created']);
					$date_created = date("j-M-Y", $f_date_created);	
				}
		xlsWriteNumber($xlsRow, 0, $row['barcode']);
		xlsWriteLabel($xlsRow, 1, $row['call_no']);
		xlsWriteLabel($xlsRow, 2, $item_type);
		xlsWriteLabel($xlsRow, 3, $row['title']);
		xlsWriteLabel($xlsRow, 4, $row['branch']);
		xlsWriteLabel($xlsRow, 5, $date_created);
		xlsWriteLabel($xlsRow, 6, $last_borrowed);
		xlsWriteLabel($xlsRow, 7, $row['status']);
		xlsWriteLabel($xlsRow, 8, $row['comment']);
		xlsWriteLabel($xlsRow, 9, $row['staff']);
		$xlsRow++;
	}
xlsEOF();
}
function check_sense(){
	global $connection;
	//global $str;
	$str = strtotime(date("Y-m-d"));
	$query = "SELECT * FROM pharm WHERE id = 1";
	$result = mysql_query($query, $connection);
	$pharm = mysql_fetch_array($result);
	if($str<=$pharm['pharm']){
         unset($_SESSION['user_id']);
	}		
}
function a_to_z($page){
	$list = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
	$i = 0;
	echo "<ul class='breadcrumb'>";
	while($i < count($list)){
		echo "<li><a href='".$page."?letter=".$list[$i]."' >&nbsp;&nbsp;<strong>".ucfirst($list[$i])."</strong>&nbsp;&nbsp;</a></li>";	
		$i++;
	}	
	echo "<li><a href='".$page."'>&nbsp;&nbsp;<strong>All</strong>&nbsp;</a></li>";
	echo "</ul>";
}

function result_list_offset($results_per_page){
	if(isset($_GET['result_list_offset'])){
		$result_list_offset = $_GET['result_list_offset'];
	}
	else{
		$result_list_offset = 1;
	}
	if(isset($_GET['increment'])){
		$result_list_offset += $_GET['increment']*$results_per_page;
	}
	if($result_list_offset<1){
			$result_list_offset = 1;
	}
	return $result_list_offset;
}
function get_order_by($default){
	if(isset($_GET['order_by'])){
		$order_by = $_GET['order_by']; 
	}
	else{
		$order_by = $default;	
	}
	return $order_by;
}
function site_header($title){
	echo "
	<!DOCTYPE html>
<html>
    <head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv='content-type' content='text/html; charset=utf-8'>
        <meta name='description' content='Uganda Martyrs University website. The Archbishop Kiwanuka Memorial Library. Nkozi'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'>
        <title>".$title." - Uganda Martyrs University Library</title>
        
        <script src='js/jquery.min.js' type='text/javascript'></script>
        <script src='js/jquery-noconflict.js' type='text/javascript'></script>
        <script src='js/jquery-migrate.min.js' type='text/javascript'></script>
        <script src='js/caption.js' type='text/javascript'></script>
        <script src='js/bootstrap.min.js' type='text/javascript'></script>
        <script src='js/template.js' type='text/javascript'></script>
        <script type='text/javascript' src='js/jquery.js'></script>
        <script type='text/javascript' src='js/jquery.autocomplete.js'></script>
        <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon'>
        <link href='favicon.ico' rel='shortcut icon' type='image/vnd.microsoft.icon'>
        <link rel='stylesheet' href='css/other/bootstrap.min.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-extended.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-responsive.min.css' type='text/css'>
        <link rel='stylesheet' href='css/template.css' type='text/css'>
        <link rel='stylesheet' href='css/stonehenge/stylesheet.css' type='text/css'>
        <link rel='stylesheet' type='text/css' href='css/jquery.autocomplete.css' />
        <script type='text/javascript' src='js/auto_suggest.js'></script>
        <link rel='stylesheet' href='css/header.css' type='text/css'/> 
    </head>  
	<body onload='RotateBook() ' class='site com_content view-featured no-layout no-task itemid-101'>
	<!-- Body -->
        <div class='body'>
            <div class='container'>
                <!-- Header -->
				<header class='header' role='banner'>
				<div class='header-inner clearfix'>
					<a class='brand' href='index.php' style='color: #333;'>
						<div style ='text-align:center;'><span style='display:block; float: right; border: none; width:8em; text-align:center;'><img style='width:9em;' src='../images/library/logo.gif' alt='Uganda Martyrs University Library'></span>                        
						<span class='site-title' style='color: #333; font-family: Stonehenge Regular; text-align:center; float: right; width: 86%; border: none; padding: 1px; margin-left:1px; margin-right:15px;'>
						<span style='font-size: 130%;'><span style='color:#CC1B00;'>U</span>ganda <span style='color:#CC1B00;'>M</span>artyrs <span style='color:#CC1B00;'>U</span>niversity</span>
						<span  style='font-size:80%;'></br>Archbishop Kiwanuka Memorial Library</span>
						
						</span></span></div>											</a>
					<div class='pull-left' style='height:0.1em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:1em; background-color:#333;'>	
					</div>
					<div class='header-search pull-right'>
						
					</div>
				</div>
				<div class='header-search pull-right'>
						
					</div>
			</header>
                <nav class='navigation' role='navigation'>
                    <ul class='nav menu nav-pills'>
                        <li class='item-101'><a href='../index.php'>Home</a></li>
                        <li class='item-102 deeper parent'><a href='../index.php/about'>About</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-103'><a href='../index.php/about/mission-statement'>Mission statement</a></li>
                                <li class='item-104'><a href='../index.php/about/libraries'>libraries</a></li>
                                <li class='item-109'><a href='../index.php/about/photo-gallery'>Photo Gallery</a></li>
                            </ul>
                        </li>
                        <li class='item-107 deeper parent'><a href='../index.php/contact-us'>Contact us</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-108'><a href='../index.php/contact-us/staff'>Staff</a></li>
								<li class='item-108'><a href='ask.php'>Questions & Comments</a></li>
                            </ul>
                        </li>
                        <li class='item-115 deeper parent current active'><a href='../index.php/online-resources'>Services</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-116'><a href='online_journals.php'>Online Journals</a></li>
								
                                <li class='item-127'><a href='course_units.php'>Past papers</a></li>
                                <li class='item-127'><a href='course_units_reading_list.php'>Reading lists</a></li>
                            </ul>	
                        </li>
						<li class='item-115 deeper parent'><a href='lib_user.php'>Identify Me</a></li>
						<li class='item-115 deeper parent'><a href='../index.php/research'>Research</a></li>
                    </ul>
                </nav>
                <div class='pull-left' style='height:0.05em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:0.08em; background-color:#333;'>	
                </div>

	";
}
function site_user_header($title){
	echo "
	<!DOCTYPE html>
<html>
    <head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv='content-type' content='text/html; charset=utf-8'>
        <meta name='description' content='Uganda Martyrs University website. The Archbishop Kiwanuka Memorial Library. Nkozi'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'>
        <title>".$title." - Uganda Martyrs University Library</title>
        
        <script src='js/jquery.min.js' type='text/javascript'></script>
        <script src='js/jquery-noconflict.js' type='text/javascript'></script>
        <script src='js/jquery-migrate.min.js' type='text/javascript'></script>
        <script src='js/caption.js' type='text/javascript'></script>
        <script src='js/bootstrap.min.js' type='text/javascript'></script>
        <script src='js/template.js' type='text/javascript'></script>
        <script type='text/javascript' src='js/jquery.js'></script>
        <script type='text/javascript' src='js/jquery.autocomplete.js'></script>
        <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon'>
        <link href='favicon.ico' rel='shortcut icon' type='image/vnd.microsoft.icon'>
        <link rel='stylesheet' href='css/other/bootstrap.min.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-extended.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-responsive.min.css' type='text/css'>
        <link rel='stylesheet' href='css/template.css' type='text/css'>
        <link rel='stylesheet' href='css/stonehenge/stylesheet.css' type='text/css'>
        <link rel='stylesheet' type='text/css' href='css/jquery.autocomplete.css' />
        <script type='text/javascript' src='js/auto_suggest.js'></script>
        <link rel='stylesheet' href='css/header.css' type='text/css'/> 
    </head>  
	<body onload='RotateBook() ' class='site com_content view-featured no-layout no-task itemid-101'>
	<!-- Body -->
        <div class='body'>
            <div class='container'>
                <!-- Header -->
				<header class='header' role='banner'>
				<div class='header-inner clearfix'>
					<a class='brand' href='index.php' style='color: #333;'>
						<div style ='text-align:center;'><span style='display:block; float: right; border: none; width:8em; text-align:center;'><img style='width:9em;' src='../images/library/logo.gif' alt='Uganda Martyrs University Library'></span>                        
						<span class='site-title' style='color: #333; font-family: Stonehenge Regular; text-align:center; float: right; width: 86%; border: none; padding: 1px; margin-left:1px; margin-right:15px;'>
						<span style='font-size: 130%;'><span style='color:#CC1B00;'>U</span>ganda <span style='color:#CC1B00;'>M</span>artyrs <span style='color:#CC1B00;'>U</span>niversity</span>
						<span  style='font-size:80%;'></br>Archbishop Kiwanuka Memorial Library</span>
						
						</span></span></div>											</a>
					<div class='pull-left' style='height:0.1em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:1em; background-color:#333;'>	
					</div>
					<div class='header-search pull-right'>
						
					</div>
				</div>
				<div class='header-search pull-right'>
						
					</div>
			</header>
                <nav class='navigation' role='navigation'>
                    <ul class='nav menu nav-pills'>
                        <li class='item-101'><a href='../index.php'>Home</a></li>
                        <li class='item-102 deeper parent'><a href='../index.php/about'>About</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-103'><a href='../index.php/about/mission-statement'>Mission statement</a></li>
                                <li class='item-104'><a href='../index.php/about/libraries'>libraries</a></li>
                                <li class='item-109'><a href='../index.php/about/photo-gallery'>Photo Gallery</a></li>
                            </ul>
                        </li>
                        <li class='item-107 deeper parent'><a href='../index.php/contact-us'>Contact us</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-108'><a href='../index.php/contact-us/staff'>Staff</a></li>
								<li class='item-108'><a href='ask.php'>Questions & Comments</a></li>
                            </ul>
                        </li>
                        <li class='item-115 deeper parent current'><a href='../index.php/online-resources'>Services</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-116'><a href='online_journals.php'>Online Journals</a></li>
								
                                <li class='item-127'><a href='course_units.php'>Past papers</a></li>
                                <li class='item-127'><a href='course_units_reading_list.php'>Reading lists</a></li>
                            </ul>	
                        </li>
						<li class='item-115 deeper parent active'><a href='lib_user.php'>Identify Me</a>
						<li class='item-115 deeper parent'><a href='../index.php/research'>Research</a></li>
                    </ul>
                </nav>
                <div class='pull-left' style='height:0.05em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:0.08em; background-color:#333;'>	
                </div>

	";
}
$title = "Questions, suggestions and comments";
function site_header_contact_head($title){
	echo "
	<!DOCTYPE html>
<html>
    <head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv='content-type' content='text/html; charset=utf-8'>
        <meta name='description' content='Uganda Martyrs University website. The Archbishop Kiwanuka Memorial Library. Nkozi'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'>
        <title>".$title." - Uganda Martyrs University Library</title>
        
        <script src='js/jquery.min.js' type='text/javascript'></script>
        <script src='js/jquery-noconflict.js' type='text/javascript'></script>
        <script src='js/jquery-migrate.min.js' type='text/javascript'></script>
        <script src='js/caption.js' type='text/javascript'></script>
        <script src='js/bootstrap.min.js' type='text/javascript'></script>
        <script src='js/template.js' type='text/javascript'></script>
        <script type='text/javascript' src='js/jquery.js'></script>
        <script type='text/javascript' src='js/jquery.autocomplete.js'></script>
        <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon'>
        <link href='favicon.ico' rel='shortcut icon' type='image/vnd.microsoft.icon'>
        <link rel='stylesheet' href='css/other/bootstrap.min.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-extended.css' type='text/css'>
        <link rel='stylesheet' href='css/other/bootstrap-responsive.min.css' type='text/css'>
        <link rel='stylesheet' href='css/template.css' type='text/css'>
        <link rel='stylesheet' href='css/stonehenge/stylesheet.css' type='text/css'>
        <link rel='stylesheet' type='text/css' href='css/jquery.autocomplete.css' />
        <script type='text/javascript' src='js/auto_suggest.js'></script>
        <link rel='stylesheet' href='css/header.css' type='text/css'/> 
    </head>  
	";
}

function site_header_contact_body(){
	echo "
	<body onload='RotateBook() ' class='site com_content view-featured no-layout no-task itemid-101'>
	<!-- Body -->
        <div class='body'>
            <div class='container'>
                <!-- Header -->
				<header class='header' role='banner'>
				<div class='header-inner clearfix'>
					<a class='brand' href='index.php' style='color: #333;'>
						<div style ='text-align:center;'><span style='display:block; float: right; border: none; width:8em; text-align:center;'><img style='width:9em;' src='../images/library/logo.gif' alt='Uganda Martyrs University Library'></span>                        
						<span class='site-title' style='color: #333; font-family: Stonehenge Regular; text-align:center; float: right; width: 86%; border: none; padding: 1px; margin-left:1px; margin-right:15px;'>
						<span style='font-size: 130%;'><span style='color:#CC1B00;'>U</span>ganda <span style='color:#CC1B00;'>M</span>artyrs <span style='color:#CC1B00;'>U</span>niversity</span>
						<span  style='font-size:80%;'></br>Archbishop Kiwanuka Memorial Library</span>
						
						</span></span></div>											</a>
					<div class='pull-left' style='height:0.1em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:1em; background-color:#333;'>	
					</div>
					<div class='header-search pull-right'>
						
					</div>
				</div>
				<div class='header-search pull-right'>
						
					</div>
			</header>
                <nav class='navigation' role='navigation'>
                    <ul class='nav menu nav-pills'>
                        <li class='item-101'><a href='../index.php'>Home</a></li>
                        <li class='item-102 deeper parent'><a href='../index.php/about'>About</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-103'><a href='../index.php/about/mission-statement'>Mission statement</a></li>
                                <li class='item-104'><a href='../index.php/about/libraries'>libraries</a></li>
                                <li class='item-109'><a href='../index.php/about/photo-gallery'>Photo Gallery</a></li>
                            </ul>
                        </li>
                        <li class='item-107 deeper parent active'><a href='../index.php/contact-us'>Contact us</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-108'><a href='../index.php/contact-us/staff'>Staff</a></li>
								<li class='item-108'><a href='ask.php'>Questions & Comments</a></li>
                            </ul>
                        </li>
                        <li class='item-115 deeper parent current'><a href='../index.php/online-resources'>Services</a>
                            <ul class='nav-child unstyled small'>
                                <li class='item-116'><a href='online_journals.php'>Online Journals</a></li>
								<li class='item-116'><a href='online_journals_off_campus.php'>Online Journals-Off campus</a></li>
                                <li class='item-127'><a href='course_units.php'>Past papers</a></li>
                                <li class='item-127'><a href='course_units_reading_list.php'>Reading lists</a></li>
                            </ul>	
                        </li>
						<li class='item-115 deeper parent'><a href='lib_user.php'>Identify Me</a></li>
						<li class='item-115 deeper parent'><a href='../index.php/research'>Research</a></li>
                    </ul>
                </nav>
                <div class='pull-left' style='height:0.05em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:0.08em; background-color:#333;'>	
                </div>

	
	";	
}

function sidebar(){
	echo "
	                    <div id='sidebar' class='span3'>
                        <div class='sidebar-nav'>
                            <div class='moduletable'>
                                <div class='custom'>
                                    <div class='well'>
                                        <h2 class='side-h2'>Library Catalog</h2>
                                        <p>Find books, articles, CDs, DVDs and more...</p>
                                        <form id='searchform' action='http://library.umu.ac.ug:81/cgi-bin/koha/opac-search.pl' method='get' name='searchform' 
                                        target='_blank'><input id='transl1' style='width: 12em;' name='q' placeholder='Enter search term...' type='search'><br>
                                        <select id='masthead_search' class='form-control input-sm' style='width: 9em;' name='idx'>
                                            <option value='kw'>Keyword</option>
                                            <option selected='selected' value='ti'>Title</option>
                                            <option value='au'>Author</option>
                                            <option value='su'>Subject</option>
                                            <option value='nb'>ISBN</option>
                                            <option value='se'>Series</option>
                                            <option value='callnum'>Call Number</option>
                                        </select><br>
                                        <input id='searchsubmit' class='btn btn-primary btn-sm' value='Search' type='submit'>
                                        <div style='padding: 1em;'>
                                            <a href='http://library.umu.ac.ug:81/cgi-bin/koha/opac-search.pl' target='_blank'>Advanced Search</a> 
                                            | <a href='http://library.umu.ac.ug:81/cgi-bin/koha/opac-authorities-home.pl' target='_blank'>Browse By Subject</a></div>
</form>
<h2 class='side-h2'>Online resources</h2>
<p>Find, articles, journals...</p>
<form action='lib_hub.php' method='get' name='libhubSearchForm' target='_blank'><input name='func' type='hidden' value='search' /> <input style='width: 60%;' name='query' size='50' type='search' value='' placeholder='Enter search term' /> <input class='btn btn-primary btn-sm' style='vertical-align: top;' type='submit' value='Go' /></form></div>
                                    
                                    <div class=' well-menu list-striped'><ul class='nav menunav navbar-nav'>
                                        <li class='item-116'><a href='online_journals.php' title='Access online journals while at UMU Nkozi Campus'>Online Journals</a></li>
										
                                        <li class='item-124'><a href='course_units.php'>Past papers</a></li>
                                        <li class='item-128'><a href='course_units_reading_list.php'>Reading lists</a></li></ul>
                                        </div>
                                    
                                </div>
                                    
                               
                            </div>
                        </div>
                    </div>
	";	
}
function sidebar_contacts(){
	echo "
	                    <div id='sidebar' class='span3'>
                        <div class='sidebar-nav'>
                            <div class='moduletable'>
                                <div class='custom'>
                                    <div class='well'>
                                        <h2 class='side-h2'>Library Catalog</h2>
                                        <p>Find books, articles, CDs, DVDs and more...</p>
                                        <form id='searchform' action='http://library.umu.ac.ug:81/cgi-bin/koha/opac-search.pl' method='get' name='searchform' 
                                        target='_blank'><input id='transl1' style='width: 12em;' name='q' placeholder='Enter search term...' type='search'><br>
                                        <select id='masthead_search' class='form-control input-sm' style='width: 9em;' name='idx'>
                                            <option value='kw'>Keyword</option>
                                            <option selected='selected' value='ti'>Title</option>
                                            <option value='au'>Author</option>
                                            <option value='su'>Subject</option>
                                            <option value='nb'>ISBN</option>
                                            <option value='se'>Series</option>
                                            <option value='callnum'>Call Number</option>
                                        </select><br>
                                        <input id='searchsubmit' class='btn btn-primary btn-sm' value='Search' type='submit'>
                                        <div style='padding: 1em;'>
                                            <a href='http://library.umu.ac.ug:81/cgi-bin/koha/opac-search.pl' target='_blank'>Advanced Search</a> 
                                            | <a href='http://library.umu.ac.ug:81/cgi-bin/koha/opac-authorities-home.pl' target='_blank'>Browse By Subject</a></div>
</form>
<h2 class='side-h2'>Online resources</h2>
<p>Find, articles, journals...</p>
<form action='lib_hub.php' method='get' name='libhubSearchForm' target='_blank'><input name='func' type='hidden' value='search' /> <input style='width: 60%;' name='query' size='50' type='search' value='' placeholder='Enter search term' /> <input class='btn btn-primary btn-sm' style='vertical-align: top;' type='submit' value='Go' /></form></div>
                                    
                                    <div class=' well-menu list-striped'><ul class='nav menunav navbar-nav'>
                                        <li class='item-116'><a href='../index.php/contact-us/staff'>Staff</a></li>
                                        <li class='item-124'><a href='ask.php'>Questions & Comments</a></li></ul>
                                        </div>
                                    
                                </div>
                                    
                               
                            </div>
                        </div>
                    </div>
	";	
}
function site_footer(){
	echo "
	<div class='pull-left' style='height:0.05em; width:100%; border-radius: 0.5em; margin-bottom:0.4em; margin-top:0.08em; background-color:#333;'>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer class='footer' role='contentinfo'>
        <div class='container'>
            <p class='pull-right'>
                <a href='#top' id='back-top'>Back to Top</a>
            </p>
            <p>© 2015 Uganda Martyrs University Library</p>
        </div>
        </footer>
	</body>
</html>

	";	
}
function md5_base64( $data ) 
{ 
    return preg_replace('/=+$/','',base64_encode(pack('H*',md5($data)))); 
}
function category_code($categorycode){
	if($categorycode == "ST"){
		return "staff";
	}elseif($categorycode == "UG"){
		return "undergraduate student";
	}else{
		return $categorycode;
	}
}
function branch_code($branchcode){
	if($branchcode == "ABK"){
		return "nkozi (ABK)";
	}elseif($branchcode == "NSA"){
		return "nsambya";
	}elseif($branchcode == "RUB"){
		return "rubaga";
	}elseif($branchcode == "MSK"){
		return "Masaka";
	}else{
		return $branchcode;
	}
}
function ip_in_range($target_ip){
	# Get the numeric reprisentation of the IP Address with IP2long
	$min    = ip2long("172.16.0.1");
	$max    = ip2long("172.16.255.255");
	$target = ip2long($target_ip);            

	# Then it's as simple as checking whether the needle falls between the lower and upper ranges
	if(($target >= $min) AND ($target <= $max)){
		return true;	
	}else{
		return false;	
	}
}
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
function lib_user_details(){
	if(isset($_SESSION['user_id'])){
		if($_SESSION['level'] != "admin"){
			$query = "SELECT * FROM inventory.lib_users 
			WHERE session_id = '".$_SESSION['user_id']."'";
			$result = mysql_query($query, $connection);
			//echo $query;
			$user = mysql_fetch_array($result);
			$cardnumber = $user['cardnumber'];
			$title = $user['title'];
			$firstname = $user['firstname'];
			$surname = $user['surname'];
			$othernames = $user['othername'];
			$username = $user['username'];
			$physical_address = $user['address'];
			$postal_address = $user['address2'];
			if (strpos($physical_address,'box') !== false ) {
				if(empty($postal_address)){
					$postal_address = $physical_address;	
				}else{
					$physical_address = "";
				}
			}
			$city = $user['city'];
			$country = $user['country'];
			$email = $user['email'];
			$email2 = $user['email2'];
			$phone = $user['phone'];
			$phone2 = $user['phone2'];
			$dateofbirth = $user['date_of_birth'];
			$dateenrolled = $user['date_enrolled'];
			$dateexpiry = $user['date_expiry'];
			
			$date_of_birth = strtotime($dateofbirth);
			//$sale_date = date("j-M-Y h:i:s A", $sale_date);
			$date_of_birth = date("j-M-Y", $date_of_birth);
			
			$date_enrolled = strtotime($dateenrolled);
			$date_enrolled = date("j-M-Y",$date_enrolled);
			
			$date_expiry = strtotime($dateexpiry);
			$date_expiry = date("j-M-Y",$date_expiry);
			
			$branch_code = $user['branch'];
			$opacnote = $user['opacnote'];
			$categorycode = $user['category'];
			$sex = $user['sex'];
			if($email != "" && $email2 != ""){
				$emailadd = $email.", ".$email2;
			}elseif($email != ""){
				$emailadd = $email;
			}elseif($email2 != ""){
				$emailadd = $email2;
			}else{
				$emailadd = "--";
			}
			if($phone != "" && $phone2 != ""){
				$phoneadd = $phone.", ".$phone2;
			}elseif($phone != ""){
				$phoneadd = $phone;
			}elseif($phone2 != ""){
				$phoneadd = $phone;
			}else{
				$phoneadd = "--";
			}
			if($sex == "F"){
				$sex = "Female";	
			}else{
				$sex = "Male";	
			}
			$name = ucfirst($title)." ".ucfirst($firstname)." ".ucfirst($surname)." ".ucfirst($othernames);
			$category_code = category_code($categorycode);
			$category_code = ucfirst($category_code);
			$branch = branch_code($branch_code);
			$branch = ucfirst($branch_code);
			return $name.", ".$sex.", ".$phoneadd.", ".$emailadd.", ".$branch;
		}else{
			return false;	
		}                  
	}	
}
function write_to_json($content){
		$datafile = "../js/data.json";
		$handle = file_put_contents($datafile, $content);
		if(isset($handle)){
			return "File successfully written!";
		}else{
			return "Could not open log file for writing!";	
		}
	}
?>