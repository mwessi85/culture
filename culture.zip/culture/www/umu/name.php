<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php
if(isset($_GET['id'])){
	$query = "SELECT * FROM names WHERE id = ".$_GET['id'];
	$result = mysql_query($query, $connection);
	$name = mysql_fetch_array($result);
}
if(isset($name)){
	$query = "SELECT * FROM clans WHERE id = ".$name['clan'];
	$result_2 = mysql_query($query, $connection);
	$clan = mysql_fetch_array($result_2);
	$clan_ = $clan['local_name'];
	$gender = $name['gender'];
	$notes = $name['notes'];
}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2><?php echo ucfirst($name['name']);?></h2>
        <?php show_errors();?>
        <?php if(!empty($message)){echo "<p class=\"notice\">".$message."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a>
        <table class='results'>
        <tr><td>Clan</td><td><?php echo "<a href='clan.php?id=".$clan['id']."'>".$clan['local_name']."</a>"; ?></td></tr>
        <tr><td>Gender</td><td><?php echo $name['gender']; ?></td></tr>
        <tr><td>Notes</td><td><?php echo $name['notes']; ?></td></tr>
        </table>
        <?php 
		$query = "SELECT * FROM names WHERE clan =".$name['clan']." AND id != ".$_GET['id'];
		$result = mysql_query($query, $connection);
		$rows = mysql_num_rows($result);
		?>
        <table>
        <tr>
        <td class='column_head'>Names (<?php echo $rows;?>)</td>
        <td class='column_head'>Gender</td>
        </tr>
        <?php 
		
		while($name = mysql_fetch_assoc($result)){
			if(isset($name)){
				$query = "SELECT * FROM clans WHERE id = ".$name['clan'];
				$result_2 = mysql_query($query, $connection);
				$clan = mysql_fetch_array($result_2);
			}
			echo "<tr>
			<td><a href='name.php?id=".$name['id']."'>".$name['name']."</a></td>
			<td>".$name['gender']."</td>
			<td>".$name['notes']."</td>
			<td><a href='name_add_edit.php?id=".$name['id']."'>Edit</a></td>
			</tr>";
		}
		?>
        </table>
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>