<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php
if(isset($_GET['id'])){
	$query = "SELECT * FROM names WHERE id = ".$_GET['id'];
	$result = mysql_query($query, $connection);
	$pre = mysql_fetch_array($result);
	$query = "SELECT * FROM clans WHERE id = ".$pre['clan'];
	$result = mysql_query($query, $connection);
	$clan = mysql_fetch_array($result);
	$action = "edit";
	$title = "Edit";	
}else{
	$action = "add";
	$title = "Add";	
}
if(isset($pre)){
	$name = $pre['name'];
	$clan = $pre['clan'];
	$gender = $pre['gender'];
	$notes = $pre['notes'];
}else{
	$name = "";
	$clan = "";
	$gender = "";
	$notes = "";	
}




if(isset($_POST['submit'])){	
	$errors = array();
	
	if(isset($_POST['name'])){
		$name = trim($_POST['name']);	
	}
	if($_POST['clan'] != ""){
		$clan = trim($_POST['clan']);	
	}else{
		$errors['clan not choosen'] = "";		
	}
	if(isset($_POST['notes'])){
		$notes = trim($_POST['notes']);	
	}
	if(isset($_POST['gender'])){
		$gender = trim($_POST['gender']);	
	}

	if(empty($errors) && $_POST['submit'] == "Add"){					
		$query = "INSERT INTO names(name, clan, gender, notes) 
				VALUES('".$name."', '".$clan."', '".$gender."', '".$notes."')";
		//echo $query;
		//exit;
		$result = mysql_query($query, $connection);
		$name_id = mysql_insert_id($connection);	
		if(isset($result)){
			$message = "The name was sucessfully added";
			header("location: names.php?id=".$name_id ."&success_message=".$message);
		}	
	}
	elseif(empty($errors) && $_POST['submit'] == "Edit"){			
		$query = "UPDATE names SET name = '".$name."', clan = '".$clan."', gender = '".$gender."', notes = '".$notes."' WHERE id = ".$_GET['id'];
		$result = mysql_query($query, $connection);
		if(isset($result)){
			$message = "The name was sucessfully updated";
			header("location: names.php?id=".$_GET['id']."&success_message=".$message);
		}
	}
}


?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2><?php echo $title;?></h2>
        <?php show_errors();?>
        <?php if(!empty($message)){echo "<p class=\"notice\">".$message."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a>
        <?php 
		//echo $sql;
		?>
        <table class='results'>
        <form autocomplete="off" action="name_add_edit.php<?php if(isset($_GET['id']))echo "?id=".$_GET['id'];?>" method="post" enctype="multipart/form-data">
            <tr>
                <td class="cell_value bold">Name:</td><td class="cell_value"><input type="search" name="name" id="name" autofocus placeholder="enter name" value="<?php echo $name; ?>" required/>
                </td>
            </tr>
            <tr>
                <td class="cell_value bold">Clan</td><td class="cell_value">
                <select name="clan" id="clan">
                <option value="<?php echo $clan?>" selected><?php if($clan != ""){echo $name;} else{echo "Enter clan";}?></option>
                <?php $item_clan= mysql_query("SELECT * FROM clans ORDER BY local_name;");
					while($select_clan = mysql_fetch_assoc($item_clan)){
						echo "<option value = '".$select_clan["id"]."' ";
						if($select_clan["id"] == $clan){
							echo " selected=\"selected\"";	
						}
						echo ">".$select_clan["local_name"]."</option>";
					}    
     			?>
            </select>
            
                </td>
            </tr>
            <tr>
                <td class="cell_value bold">Gender</td><td class="cell_value">
                <input type="radio" name="gender" value="male" 
				<?php 
                if($gender == "male"){
                    echo " checked ";
                }
                ?>/> Male        
                <input type="radio" name="gender" value="female" 
                <?php 
                if($gender == "female"){
                    echo " checked ";
                }
                ?>/> Female
                </td>
            </tr>
            <tr>
                <td class="cell_value bold">Notes:</td><td class="cell_value"><textarea name="notes" rows="10"placeholder="Give brief notes associated with the name"><?php echo $notes;?></textarea>
                </td>
            </tr>
            <tr>
            <tr>
            <td class="cell_value"></td><td class="cell_value"><input type="submit" name="submit" id="submit" value="<?php echo ucfirst($action);?>" /></td>
            </tr>
        </form>
        </tr>
        </table>
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>