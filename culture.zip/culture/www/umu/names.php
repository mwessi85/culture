<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My HTML document</title>
</head>
<body>
<div id="container">
	<div id="main-copy">
        <h2>Clans</h2>
        <?php show_errors();?>
        <?php if(!empty($message)){echo "<p class=\"notice\">".$message."</p>";}?>
       <a href="home.php">Home</a> | <a href="clans.php">Clans</a> - <a href="clan_add_edit.php">Add</a> | <a href="names.php">Names</a> - <a href="name_add_edit.php">Add</a>
        <?php 
		//echo $sql;
		?>
        <table class="results">
        <tr>
        <form name="form1" id="form1" autocomplete="off" action="books.php" method="post" enctype="multipart/form-data" >
        <td class="cell_value bold">Search</td>
        <td class="cell_value"><input type="search" name="clan" id="clan" maxlength="50" value="" autofocus placeholder="enter clan name..."/>
        <input type="submit" name="search" id="search" value="Go" />
        </td>
        </form>
        <?php 
		$query = "SELECT * FROM names";
		$result = mysql_query($query, $connection);
		$rows = mysql_num_rows($result);
		?>
        </tr>
        </table>
        </div>
        <table class='results'>
        <tr>
        <td class='column_head'>Names (<?php echo $rows;?>)</td>
        <td class='column_head'>Clan</td>
        <td class='column_head'>Gender</td>
        <td class='column_head'>Notes</td>
        </tr>
        <?php 
		while($name = mysql_fetch_assoc($result)){
			if(isset($name)){
				$query = "SELECT * FROM clans WHERE id = ".$name['clan'];
				$result_2 = mysql_query($query, $connection);
				$clan = mysql_fetch_array($result_2);
			}
			echo "<tr>
			<td><a href='name.php?id=".$name['id']."'>".$name['name']."</td>
			<td>".$clan['local_name']."</td>
			<td>".$name['gender']."</td>
			<td><a href='name_add_edit.php?id=".$name['id']."'>Edit</a></td>
			</tr>";
		}
        ?>
        </table>
        <div id="footer">
         <?php 
		if(isset($connection)){
			mysql_close($connection);
		}
		?>
        <p>Uganda Martyrs University</p>
        </div>
    
</div>
</body>